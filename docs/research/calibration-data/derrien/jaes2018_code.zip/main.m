%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% "True-lossless Audio Detector" for MPEG AAC codec           %
% Dectection of traces of previous AAC encoding-decoding      %
% Developped for Matlab 8 (R2017)                             %
% Parallel computing toolbox is recommended but not necessary %
% by Olivier DERRIEN - CNRS/PRISM - Marseille - France        %
% Version 1.4, june 2018                                      %
% This distribution is for personnal use or research purpose  %
% Commercial use is prohibited                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;

% --------------- Initialization --------------------

% Browse for the input signal
[name, path] = uigetfile('*.wav','MPEG-AAC Coding-decoding detection');
fprintf(['Input file : ',name,'\n']);

tic

% Read the input signal and channel analysis
[signal, Fs] = audioread([path name]);
Fs = round(Fs/1000);
channels = size(signal,2);

% Channels processing in stereo
if channels == 2
    % LR mode (double mono)
    signal_L = signal(:,1);
    signal_R = signal(:,2);
    % MS mode (matrix stereo)
    signal_M = signal_L + signal_R;
    signal_S = signal_L - signal_R;
end

% Print information about the input signal
fprintf('Sampling frequency : %d kHz\n',Fs);
fprintf('Number of channels : %d\n',channels);

% Initialize MPEG-AAC constants
[nb_short_win, iblen_long, iblen_short, offset_short, ...
    nb_sb_long, nb_sb_short, w_low_swb_long, w_high_swb_long, ...
    w_low_swb_short, w_high_swb_short, wn_long_sin, wn_start_sin, ...
    wn_stop_sin, wn_short_sin] = init_aac(Fs);

% Compute the detection threshold for each window
ref_proba = 1e-2;
swb_width_long = w_high_swb_long - w_low_swb_long + 1;
swb_width_short = (w_high_swb_short - w_low_swb_short + 1)*nb_short_win;
mu = 1/12;
sigma_long = sqrt(1./swb_width_long/180);
sigma_short = sqrt(1./swb_width_short/180);
tau_sb_long = mu - sqrt(2)*sigma_long.*erfinv(erf(mu./sigma_long/sqrt(2))-2*ref_proba);
tau_sb_short = mu - sqrt(2)*sigma_short.*erfinv(erf(mu./sigma_short/sqrt(2))-2*ref_proba);

% Set detection parameters
nb_win = 8;
nb_sf = nb_win;
sf_min = 0.3;
sf_max = 0.7;
sf = sf_min:(sf_max-sf_min)/(nb_sf-1):sf_max;
fprintf('Frames used for detection = %d\n',nb_win);
fprintf('Scalefactors used for detection = %d\n',nb_sf);
fprintf('Analyzing the audio signal ... please wait\n');

% Set the significance threshold
significance_thr = 0.031; % for nb_win = nb_sf = 8
%significance_thr = 0.019; % for nb_win = nb_sf = 16
%significance_thr = 0.0145; % for nb_win = nb_sf = 32

% --------------- Detection --------------------

if channels == 1
    
    % Monophonic case
    
    % Compute signal energy in 2048-samples-long windows
    Nw_max = floor(length(signal)/iblen_long)-2;
    Energy = zeros(1, Nw_max);
    for nw = 1 : Nw_max
        Energy(nw) = sum(signal((nw-1)*iblen_long+1 : (nw+1)*iblen_long).^2);
    end
    Energy = 10*log10(Energy);
    
    % Select high-energy windows
    [~, index] = sort(Energy,'descend');
    selected_windows = index(1:nb_win);
    
    % Loop on offset
    buffer_proba_sin = zeros(1, iblen_long);
    parfor offset = 0 : iblen_long-1
        
        % Detect AAC quantization, sine windows
        buffer_proba_sin(offset+1) = detect_aac(signal, offset, sf, selected_windows, ...
            iblen_long, iblen_short, offset_short, nb_sb_long, nb_sb_short, nb_short_win, ...
            w_low_swb_long, w_high_swb_long, w_low_swb_short, w_high_swb_short, wn_long_sin, ...
            wn_start_sin, wn_stop_sin, wn_short_sin, tau_sb_long, tau_sb_short);
        
    end
    
    % Keep the highest estimate for each window shape
    [proba_sin, offset_sin] = max(buffer_proba_sin);
    
    fprintf('Signal analysis completed:\n');
    
    % Significance test
    if proba_sin > significance_thr
        
        % Mesures are significant
        fprintf('  Most probable offset: %d samples\n', offet_sin-1);
        fprintf('  Likelihood for transcoded audio: %d %%\n', round(proba_sin*100));
        
    else
        
        % Measures are not significant
        fprintf('   No significant traces of previous AAC coding-decoding\n');
        
    end
    
else
    
    % Stereophonic case
    
    % Compute signal energy in 2048-samples-long windows, all channels
    Nw_max = floor(length(signal_M)/iblen_long)-2;
    Energy_L = zeros(1, Nw_max);
    Energy_R = zeros(1, Nw_max);
    Energy_M = zeros(1, Nw_max);
    Energy_S = zeros(1, Nw_max);
    for nw = 1 : Nw_max
        Energy_L(nw) = sum(signal_L((nw-1)*iblen_long+1 : (nw+1)*iblen_long).^2);
        Energy_R(nw) = sum(signal_R((nw-1)*iblen_long+1 : (nw+1)*iblen_long).^2);
        Energy_M(nw) = sum(signal_M((nw-1)*iblen_long+1 : (nw+1)*iblen_long).^2);
        Energy_S(nw) = sum(signal_S((nw-1)*iblen_long+1 : (nw+1)*iblen_long).^2);
    end
    Energy_L = 10*log10(Energy_L);
    Energy_R = 10*log10(Energy_R);
    Energy_M = 10*log10(Energy_M);
    Energy_S = 10*log10(Energy_S);
    
    % Select high-energy windows on M channel only
    [~, index] = sort(Energy_M,'descend');
    selected_windows = index(1:nb_win);
    
    % Compute mean energy on selected windows, for all channels
    Energy_win_L = mean(Energy_L(selected_windows));
    Energy_win_R = mean(Energy_R(selected_windows));
    Energy_win_M = mean(Energy_M(selected_windows));
    Energy_win_S = mean(Energy_S(selected_windows));
    
    % Loop on offset
    buffer_proba_LR_sin = zeros(1, iblen_long);
    buffer_proba_MS_sin = zeros(1, iblen_long);
    for offset = 0 : iblen_long-1
        
        % Detect AAC quantization in LR mode, sine windows
        if Energy_win_L >= Energy_win_R
            buffer_proba_LR_sin(offset+1) = detect_aac(signal_L, offset, sf, selected_windows, ...
                iblen_long, iblen_short, offset_short, nb_sb_long, nb_sb_short, nb_short_win, ...
                w_low_swb_long, w_high_swb_long, w_low_swb_short, w_high_swb_short, wn_long_sin, ...
                wn_start_sin, wn_stop_sin, wn_short_sin, tau_sb_long, tau_sb_short);
        else
            buffer_proba_LR_sin(offset+1) = detect_aac(signal_R, offset, sf, selected_windows, ...
                iblen_long, iblen_short, offset_short, nb_sb_long, nb_sb_short, nb_short_win, ...
                w_low_swb_long, w_high_swb_long, w_low_swb_short, w_high_swb_short, wn_long_sin, ...
                wn_start_sin, wn_stop_sin, wn_short_sin, tau_sb_long, tau_sb_short);
        end
        
        % Detect AAC quantization in MS mode, sine windows
        if Energy_win_M >= Energy_win_S
            buffer_proba_MS_sin(offset+1) = detect_aac(signal_M, offset, sf, selected_windows, ...
                iblen_long, iblen_short, offset_short, nb_sb_long, nb_sb_short, nb_short_win, ...
                w_low_swb_long, w_high_swb_long, w_low_swb_short, w_high_swb_short, wn_long_sin, ...
                wn_start_sin, wn_stop_sin, wn_short_sin, tau_sb_long, tau_sb_short);
        else
            buffer_proba_MS_sin(offset+1) = detect_aac(signal_S, offset, sf, selected_windows, ...
                iblen_long, iblen_short, offset_short, nb_sb_long, nb_sb_short, nb_short_win, ...
                w_low_swb_long, w_high_swb_long, w_low_swb_short, w_high_swb_short, wn_long_sin, ...
                wn_start_sin, wn_stop_sin, wn_short_sin, tau_sb_long, tau_sb_short);
        end
        
    end
    
    % Keep the highest estimate for each configuration
    [proba_LR_sin, offset_LR_sin] = max(buffer_proba_LR_sin);
    [proba_MS_sin, offset_MS_sin] = max(buffer_proba_MS_sin);
    proba_sin = max([proba_LR_sin, proba_MS_sin]);
    
    fprintf('Signal analysis completed:\n');
    
    % Significance test
    if proba_sin > significance_thr
        
        % Measures are significant
        if proba_LR_sin > proba_MS_sin
            fprintf('Most probable offset: %d samples', offset_LR_sin-1);
            fprintf('Likelihood for transcoded audio: %d %%\n', round(proba_LR_sin*100));
        else
            fprintf('Most probable offset: %d samples\n', offset_MS_sin-1);
            fprintf('Likelihood for transcoded audio: %d %%\n', round(proba_MS_sin*100));
        end
        
    else
        
        % Measures are not significant
        fprintf('   No significant traces of previous AAC coding-decoding\n');
        
    end
end

fprintf('\n');

toc

