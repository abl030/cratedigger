function X = MDCT(x)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fast computation of MDCT using FFT                   %
% by Olivier DERRIEN - CNRS/PRISM - Marseille - France %
% Version 1.4, june 2018                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get MDCT size
N = length(x);
N = N/2;

% Discrete time and frequency vectors 
t = [0:2*N-1];
f = [0:N-1];

% MDCT computation using FFT
X = x .* exp(-j*pi*t/2/N);
X = fft(X);
X = X(1:N);
X = real(X .* exp(-j*pi*(f+0.5)*(N+1)/2/N));
