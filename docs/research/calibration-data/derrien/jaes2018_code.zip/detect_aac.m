function proba_cod = detect_aac(signal, offset, sf, selected_windows, ...
    iblen_long, iblen_short, offset_short, nb_sb_long, nb_sb_short, ...
    nb_short_windows, w_low_swb_long, w_high_swb_long, w_low_swb_short, ...
    w_high_swb_short, wn_long, wn_start, wn_stop, wn_short, tau_sb_long, tau_sb_short)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% "True-lossless Audio Detector" for MPEG AAC codec           %
% Dectection of traces of previous AAC encoding-decoding      %
% Quantization-detection module                               % 
% Developped for Matlab 8 (R2017)                             %
% by Olivier DERRIEN - CNRS/PRISM - Marseille - France        %
% Version 1.4, june 2018                                      %
% This distribution is for personnal use or research purpose  %
% Commercial use is prohibited                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialize the counting buffer
buffer_count_tot = zeros(2, 1);

% Loop on analysis windows
for nf = 1 : length(selected_windows)
    
    % Extract the current analysis window: 2048 samples + offset
    no_fen = selected_windows(nf);
    signal_win = signal((no_fen-1)*iblen_long+offset+1 : (no_fen+1)*iblen_long+offset);
                                                                   
    % Apply 2048-samples MDCT, long windows (standard long, long start and long stop)
    mdct_long = MDCT((wn_long .* signal_win)');
    mdct_start = MDCT((wn_start .* signal_win)');
    mdct_stop = MDCT((wn_stop .* signal_win)');
    
    % Extract short windows and applying 256-samples MDCT
    mdct_short = zeros(iblen_short, nb_short_windows);
    for nb_sb_win = 1 : nb_short_windows
        n1 = (nb_sb_win - 1) * iblen_short + 1 + offset_short;
        zn = wn_short .* signal_win(n1 : n1 + 2*iblen_short - 1);
        mdct_short(:, nb_sb_win) = MDCT(zn');
    end
        
    % Loop on subbands, long windows
    buffer_count_long_win = zeros(2, 1);
    buffer_count_long_start = zeros(2, 1);
    buffer_count_long_stop = zeros(2, 1);
    
    for s = 1 : nb_sb_long-1
        
        % Extract the current subband
        mdct_sb_long = mdct_long(w_low_swb_long(s) : w_high_swb_long(s));
        mdct_sb_start = mdct_start(w_low_swb_long(s) : w_high_swb_long(s));
        mdct_sb_stop = mdct_stop(w_low_swb_long(s) : w_high_swb_long(s));
        
        % Compute the maximum scalefactor values
        SF_max_long = 4*log2(max(abs(mdct_sb_long)))+16/3+60;
        SF_max_start = 4*log2(max(abs(mdct_sb_start)))+16/3+60;
        SF_max_stop = 4*log2(max(abs(mdct_sb_stop)))+16/3+60;
        
        % Loop on scalefactor values
        Er_sb_long = zeros(size(sf));
        Er_sb_start = zeros(size(sf));
        Er_sb_stop = zeros(size(sf));
        for k = 1 : length(sf)
            
            % Apply quantization
            mdct_sc_long = abs(mdct_sb_long).^(3/4) * 2^(-3/16*(sf(k)*SF_max_long-60));
            mdct_sc_start = abs(mdct_sb_start).^(3/4) * 2^(-3/16*(sf(k)*SF_max_start-60));
            mdct_sc_stop = abs(mdct_sb_stop).^(3/4) * 2^(-3/16*(sf(k)*SF_max_stop-60));
            
            % Compute the energy of quantization error
            Er_sb_long(k) = mean((round(mdct_sc_long)-mdct_sc_long).^2);
            Er_sb_start(k) = mean((round(mdct_sc_start)-mdct_sc_start).^2);
            Er_sb_stop(k) = mean((round(mdct_sc_stop)-mdct_sc_stop).^2);
        end
                
        % Update counting buffers
        count_long = sum(Er_sb_long < tau_sb_long(s));
        count_start = sum(Er_sb_start < tau_sb_long(s));
        count_stop = sum(Er_sb_stop < tau_sb_long(s));
        buffer_count_long_win(1) = buffer_count_long_win(1) + count_long;
        buffer_count_long_win(2) = buffer_count_long_win(2) + length(sf);
        buffer_count_long_start(1) = buffer_count_long_start(1) + count_start;
        buffer_count_long_start(2) = buffer_count_long_start(2) + length(sf);
        buffer_count_long_stop(1) = buffer_count_long_stop(1) + count_stop;
        buffer_count_long_stop(2) = buffer_count_long_stop(2) + length(sf);
                
    end
    
    % Loop on subbands, short windows
    buffer_count_short_win = zeros(2, 1);
    for s = 1 : nb_sb_short-1
        
        % Extract the current subband
        mdct_sb_short = mdct_short(w_low_swb_short(s) : w_high_swb_short(s), :);
        mdct_sb_short = reshape(mdct_sb_short,size(mdct_sb_short,1)*size(mdct_sb_short,2),1);
        
        % Compute the maximum scalefactor values
        SF_max_short = 4*log2(max(abs(mdct_sb_short)))+16/3+60;
                
        % Loop on scalefactor values
        Er_sb_short = zeros(size(sf));
        for k = 1 : length(sf)
            
            % Apply quantization
            mdct_sc_short = abs(mdct_sb_short).^(3/4) * 2^(-3/16*(sf(k)*SF_max_short-60));
            
            % Compute the energy of quantization error
            Er_sb_short(k) = mean((round(mdct_sc_short)-mdct_sc_short).^2);
            
        end        
        
        % Update counting buffers
        count_short = sum(Er_sb_short < tau_sb_short(s));
        buffer_count_short_win(1) = buffer_count_short_win(1) + count_short;
        buffer_count_short_win(2) = buffer_count_short_win(2) + length(sf);
                
    end
    
    % Select the most probable windows shape and MDCT size
    proba_long = buffer_count_long_win(1) / buffer_count_long_win(2);
    proba_start = buffer_count_long_start(1) / buffer_count_long_start(2);
    proba_stop = buffer_count_long_stop(1) / buffer_count_long_stop(2);
    proba_short = buffer_count_short_win(1) / buffer_count_short_win(2);
    [~,idx] = max([proba_long proba_start proba_stop proba_short]);
    switch idx
        case 1,
            buffer_count_tot(1) = buffer_count_tot(1) + buffer_count_long_win(1);
            buffer_count_tot(2) = buffer_count_tot(2) + buffer_count_long_win(2);
        case 2,
            buffer_count_tot(1) = buffer_count_tot(1) + buffer_count_long_start(1);
            buffer_count_tot(2) = buffer_count_tot(2) + buffer_count_long_start(2);
        case 3,
            buffer_count_tot(1) = buffer_count_tot(1) + buffer_count_long_stop(1);
            buffer_count_tot(2) = buffer_count_tot(2) + buffer_count_long_stop(2);
        case 4,
            buffer_count_tot(1) = buffer_count_tot(1) + buffer_count_short_win(1);
            buffer_count_tot(2) = buffer_count_tot(2) + buffer_count_short_win(2);
    end
             
end

% Compute the final estimation of thresholding probability
proba_cod = buffer_count_tot(1) / buffer_count_tot(2);








