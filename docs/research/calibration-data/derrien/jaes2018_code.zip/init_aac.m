function [nb_short_win, iblen_long, iblen_short, offset_short, ...
    nb_sb_long, nb_sb_short, w_low_swb_long, w_high_swb_long, ...
    w_low_swb_short, w_high_swb_short, wn_long_sin, wn_start_sin, ...
    wn_stop_sin, wn_short_sin] = init_aac(Fs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% "True-lossless Audio Detector" for MPEG AAC codec           %
% Dectection of traces of previous AAC encoding-decoding      %
% Initialization module                                       % 
% Developped for Matlab 8 (R2017)                             %
% by Olivier DERRIEN - CNRS/PRISM - Marseille - France        %
% Version 1.4, june 2018                                      %
% This distribution is for personnal use or research purpose  %
% Commercial use is prohibited                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ----------------------------------------------

% Length of MDCT windows 
iblen_short = 128; 
iblen_long = 1024; 
nb_short_win = iblen_long / iblen_short; 
offset_short = (iblen_long - iblen_short) / 2;

% Table of subband start index
switch Fs

   case 32,

   w_low_swb_long = [1 5 9 13 17 21 25 29 33 37 41 49 57 65 73 81 89 97 109 121 133 145 ...
      161 177 197 217 241 265 293 321 353 385 417 449 481 513 545 577 609 641 673 705 737 ...
      769 801 833 865 897 929 961 993]';
   w_low_swb_short = [1 5 9 13 17 21 29 37 45 57 69 81 97 113]';

   case 44,

   w_low_swb_long = [1 5 9 13 17 21 25 29 33 37 41 49 57 65 73 81 89 97 109 121 133 145 ...
      161 177 197 217 241 265 293 321 353 385 417 449 481 513 545 577 609 641 673 705 737 ...
      769 801 833 865 897 929]';
   w_low_swb_short = [1 5 9 13 17 21 29 37 45 57 69 81 97 113]';

   case 48,
       
   w_low_swb_long = [1 5 9 13 17 21 25 29 33 37 41 49 57 65 73 81 89 97 109 121 133 145 ...
      161 177 197 217 241 265 293 321 353 385 417 449 481 513 545 577 609 641 673 705 737 ...
      769 801 833 865 897 929]';  
   w_low_swb_short = [1 5 9 13 17 21 29 37 45 57 69 81 97 113]';
    
end

% Computing the number of subbands
nb_sb_long = length(w_low_swb_long);
nb_sb_short = length(w_low_swb_short);

% Computing subband stop index
w_high_swb_long = zeros (size(w_low_swb_long)); 
for b = 1 : nb_sb_long - 1,
   w_high_swb_long (b) = w_low_swb_long (b + 1) - 1;
end 
w_high_swb_long (nb_sb_long) = iblen_long; 

w_high_swb_short = zeros (size(w_low_swb_short)); 
for b = 1 : nb_sb_short - 1,
   w_high_swb_short (b) = w_low_swb_short (b + 1) - 1; 
end 
w_high_swb_short (nb_sb_short) = iblen_short;

% Compute MDCT windows, sine shape
N = 2*iblen_long;
wn_left_2048 = sin(pi*(2*(0:N/2-1)'+1)/N/2);
wn_right_2048 = sin(pi*(2*(N/2:N-1)'+1)/N/2);

N = 2*iblen_short;
wn_left_256 = sin(pi*(2*(0:N/2-1)'+1)/N/2);
wn_right_256 = sin(pi*(2*(N/2:N-1)'+1)/N/2);

wn_long_sin = [wn_left_2048; wn_right_2048];
wn_start_sin = [wn_left_2048; ones(offset_short,1); wn_right_256; zeros(offset_short,1)];
wn_stop_sin = [zeros(offset_short,1); wn_left_256; ones(offset_short,1); wn_right_2048];
wn_short_sin = [wn_left_256; wn_right_256];

